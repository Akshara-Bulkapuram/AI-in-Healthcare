const EHR = artifacts.require('EHR')

module.exports = function (deployer) {
  deployer.deploy(EHR)
}
