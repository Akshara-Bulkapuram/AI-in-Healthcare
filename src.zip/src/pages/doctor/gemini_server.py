# gemini_api.py
import os
from flask import Flask, request, jsonify
from gemini_ocr import extract_prescription_data 
from error_checker import check_prescription_error
from flask_cors import CORS
import logging

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
logging.basicConfig(level=logging.DEBUG)
@app.route('/extract-prescription', methods=['POST'])
def extract_prescription():
    data = request.json
    print(data)
    print('type of data is ' ,type(data))
    image_path = data["image_path"]
    print('type of image is ' ,type(data))
    print(image_path)
    if not image_path:
        return jsonify({"error": "Image path not provided"}), 400
    try:
        result = extract_prescription_data(str(image_path))
        print(result)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/check-prescription-error', methods=['POST'])
def check_error():
    data = request.json
    prescription_json = data.get("prescription_json")
    if not prescription_json:
        return jsonify({"error": "Prescription JSON not provided"}), 400
    try:
        result = check_prescription_error(prescription_json)
        print(result)
        return jsonify({"error_check_result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
