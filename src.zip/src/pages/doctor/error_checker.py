# gemini_extraction.py

import os
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def check_prescription_error(json):

    # Access the Gemini API key
    api_key = os.getenv("GEMINI_API_KEY")
    genai.configure(api_key=api_key)

    # Set up generation configuration for the model
    generation_config = {
        "temperature": 1,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }

    # Initialize the Gemini model
    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash",
        generation_config=generation_config,
    )

    # Start a chat session without history for a fresh query
    chat_session = model.start_chat(history=[])

    # Define the query for extraction
    query = """
    Analyse the JSON input and Check if each drug in the prescribed_drug list is commonly prescribed for the given disease. 
    If all drugs are suitable for treating the specified disease, output you give should only be of type (0) or (1) where (0) if all prescribed drugs are suitable for the disease.
    (1) if there is any inconsistency (prescription error).

    only give correct (0) or incorrect(1)

    """

    # Generate content by combining the image with the specified query
    result = model.generate_content([json, "\n\n", query])

    # Return the response text in JSON format
    return result.text
