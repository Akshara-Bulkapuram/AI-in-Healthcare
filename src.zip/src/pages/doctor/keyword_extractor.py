# medbert_keyword_extractor.py

import torch
from transformers import AutoTokenizer, AutoModel
import csv

class MedBERTKeywordExtractor:
    def __init__(self, model_name="emilyalsentzer/Bio_ClinicalBERT"):
        # Initialize the tokenizer and model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name, output_attentions=True)
    
    def preprocess_text(self, text):
        # Tokenize the input text
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True)
        return inputs

    def extract_keywords(self, text, attention_threshold=0.01):
        # Preprocess text
        inputs = self.preprocess_text(text)
        
        # Get model outputs with attention weights
        with torch.no_grad():
            outputs = self.model(**inputs)
        
        # Average attention scores across layers and heads
        attention = outputs.attentions  # Shape: (layers, batch, heads, sequence_length, sequence_length)
        avg_attention = torch.mean(torch.stack(attention), dim=(0, 1, 2))  # Average over layers and heads

        # Define a threshold for selecting keywords
        threshold = avg_attention.mean() + avg_attention.std() * attention_threshold
        
        # Extract tokens with high attention scores
        keywords = [
            self.tokenizer.decode([inputs["input_ids"][0][i]])
            for i, score in enumerate(avg_attention[0])
            if score > threshold
        ]
        return keywords

    def save_to_csv(self, text, keywords, output_path="extracted_keywords.csv"):
        # Save extracted keywords to CSV
        with open(output_path, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Text', 'Keywords'])
            writer.writerow([text, ', '.join(keywords)])
        print(f"Keywords saved to {output_path}")

    def extract_and_save(self, text, output_path="extracted_keywords.csv"):
        # Full pipeline to extract keywords and save to CSV
        keywords = self.extract_keywords(text)
        self.save_to_csv(text, keywords, output_path)
        return keywords

# Usage example
if __name__ == "__main__":
    # Example medical text
    text = "The patient presents with hypertension and chronic kidney disease."

    # Initialize extractor and perform extraction
    extractor = MedBERTKeywordExtractor()
    keywords = extractor.extract_and_save(text)

    print("Extracted Keywords:", keywords)
