# gemini_extraction.py

import os
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def extract_prescription_data(image_path):
    print('from_function_extract, ', image_path, " ", type(image_path))

    """
    Extracts disease, prescribed drug, and symptoms from a prescription image.

    Parameters:
    - image_path (str): Path to the image file containing prescription details.

    Returns:
    - str: JSON response containing extracted information about disease, drug, and symptoms.
    """
    # Access the Gemini API key
    api_key = os.getenv("GEMINI_API_KEY")
    genai.configure(api_key=api_key)

    # Set up generation configuration for the model
    generation_config = {
        "temperature": 1,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
        "response_mime_type": "text/plain",
    }

    # Initialize the Gemini model
    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash",
        generation_config=generation_config,
    )

    # Start a chat session without history for a fresh query
    chat_session = model.start_chat(history=[])

    # Upload the image file
    myfile = genai.upload_file(image_path)
    print(f"myfile = {myfile}")

    # Define the query for extraction
    query = """
    Extract the following information from the image:

    - Disease: Name of any diagnosed condition or illness visible.
    - Prescribed Drug: Name of any drug visible in the image.
    - Symptoms: Any symptoms identifiable in the image.

    Answer in JSON format:
    {
        "disease": ["..."],
        "prescribed_drug": ["..."],
        "symptoms": ["..."]
    }
    """

    # Generate content by combining the image with the specified query
    result = model.generate_content([myfile, "\n\n", query])

    # Return the response text in JSON format
    return result.text
