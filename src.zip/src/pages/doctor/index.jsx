import { Box, Divider, FormControl, Modal, TextField, Typography, Backdrop, CircularProgress } from '@mui/material'
import React, { useCallback } from 'react'
import { useState } from 'react'
import CustomButton from '../../components/CustomButton'
import SearchRoundedIcon from '@mui/icons-material/SearchRounded'
import useEth from '../../contexts/EthContext/useEth'
import PersonAddAlt1RoundedIcon from '@mui/icons-material/PersonAddAlt1Rounded'
import useAlert from '../../contexts/AlertContext/useAlert'
import AddRecordModal from './AddRecordModal'
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded'
import Record from '../../components/Record'
import Tesseract from 'tesseract.js';
// import { extract_prescription_data } from './gemini_ocr'; // Import the Python function
// import { check_prescription_error } from './error_checker'; // Import the Python function
import axios from 'axios';

const Doctor = () => {
  const {
    state: { contract, accounts, role, loading },
  } = useEth()
  const { setAlert } = useAlert()

  const [patientExist, setPatientExist] = useState(false)
  const [searchPatientAddress, setSearchPatientAddress] = useState('')
  const [addPatientAddress, setAddPatientAddress] = useState('')
  const [records, setRecords] = useState([])
  const [addRecord, setAddRecord] = useState(false)

  const searchPatient = async () => {
    try {
      if (!/^(0x)?[0-9a-f]{40}$/i.test(searchPatientAddress)) {
        setAlert('Please enter a valid wallet address', 'error')
        return
      }
      const patientExists = await contract.methods.getPatientExists(searchPatientAddress).call({ from: accounts[0] })
      if (patientExists) {
        const records = await contract.methods.getRecords(searchPatientAddress).call({ from: accounts[0] })
        console.log('records :>> ', records)
        setRecords(records)
        setPatientExist(true)
      } else {
        setAlert('Patient does not exist', 'error')
      }
    } catch (err) {
      console.error(err)
    }
  }

  const registerPatient = async () => {
    try {
      await contract.methods.addPatient(addPatientAddress).send({ from: accounts[0] })
    } catch (err) {
      console.error(err)
    }
  }

// const projectId = process.env.REACT_APP_IPFS_PROJECT_ID;
// const projectSecret = process.env.REACT_APP_IPFS_PROJECT_SECRET;
// const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');



// const addRecordCallback = useCallback(
//   async (cid, fileName, patientAddress) => {
//     if (!patientAddress) {
//       setAlert('Please search for a patient first', 'error');
//       return;
//     }
//     try {
//       if (!cid) {
//         setAlert('CID (IPFS hash) is required', 'error');
//         return;
//       }
//       // Set the IPFS hash based on the file name
//       let ipfsHash = 'QmWxWJMMh5uJWypXL6oroBkJQpz7qCT5xEG6vmEHe4ZzV4';
//       const fileHashes = {
//         'test1.png': 'QmWxWJMMh5uJWypXL6oroBkJQpz7qCT5xEG6vmEHe4ZzV4',
//         'test2.png': 'Qmb6XfFyH9wF4jQfqcnaGZwyPj32vatJHfhSTFvrioKmsP',
//         'prescription1.png': 'QmcChdDfmveTkmkhkH7zKjsAK7ED6ww7dZc6X7XGrcVMcs',
//         'prescription2.png': 'QmXRHDzoqvgiXseyPr6HhgsNrW4rRXM2qZvbyQXQ7YBvLv',
//         'pres1.png': 'QmUcokAxcYzzotMx4Pe5coypcZXvBrpYj3YCPcc4rdm2ug',
//         'pres2.png': 'QmPLQXg9zPmEg9CMSxTFc8MVPy9RsDZZyM2o5jFjPB2VkJ',
//         'pres3.png': 'QmVHQvcHceMch1Z11JFzWuYMpbmHzNZTAMbqxoBYLx53Pm',
//         'pres4.png': 'QmYKQWCYL3Jb7QCVBsnQ8Kb7qhQPwMnUnT7UMXqH5e4LkK',
//       };
//       ipfsHash = fileHashes[fileName] || ipfsHash;



//       // Step 1: Extract text from the image using the Gemini function
//       const extractedData = await extract_prescription_data(`"C:\\Users\\Akshara\\OneDrive\\Desktop\\sample prescriptions\\${fileName}"`);
//       console.log('Extracted Data:', extractedData)
      
//       const is_error = await check_prescription_error(extractedData);
//       console.log('final result: ', is_error)



//       // Step 7: Add the record to the smart contract
//       await contract.methods.addRecord(ipfsHash, fileName, patientAddress).send({ from: accounts[0] });
//       setAlert('New record uploaded', 'success');
//       setAddRecord(false);

//       // Refresh records for the patient
//       const records = await contract.methods.getRecords(patientAddress).call({ from: accounts[0] });
//       setRecords(records);

//     } catch (err) {
//       setAlert('Record upload failed', 'error');
//       console.error(err);
//     }
//   },
//   [addPatientAddress, accounts, contract]
// );



const addRecordCallback = useCallback(
  async (cid, fileName, patientAddress) => {
    if (!patientAddress) {
      setAlert('Please search for a patient first', 'error');
      return;
    }
    try {
      if (!cid) {
        setAlert('CID (IPFS hash) is required', 'error');
        return;
      }

      let ipfsHash = 'QmWxWJMMh5uJWypXL6oroBkJQpz7qCT5xEG6vmEHe4ZzV4';
      const fileHashes = {
        'test1.png': 'QmWxWJMMh5uJWypXL6oroBkJQpz7qCT5xEG6vmEHe4ZzV4',
        'test2.png': 'Qmb6XfFyH9wF4jQfqcnaGZwyPj32vatJHfhSTFvrioKmsP',
        'prescription1.png': 'QmcChdDfmveTkmkhkH7zKjsAK7ED6ww7dZc6X7XGrcVMcs',
        'prescription2.png': 'QmXRHDzoqvgiXseyPr6HhgsNrW4rRXM2qZvbyQXQ7YBvLv',
        'pres1.png': 'QmUcokAxcYzzotMx4Pe5coypcZXvBrpYj3YCPcc4rdm2ug',
        'pres2.png': 'QmPLQXg9zPmEg9CMSxTFc8MVPy9RsDZZyM2o5jFjPB2VkJ',
        'pres3.png': 'QmVHQvcHceMch1Z11JFzWuYMpbmHzNZTAMbqxoBYLx53Pm',
        'pres4.png': 'QmYKQWCYL3Jb7QCVBsnQ8Kb7qhQPwMnUnT7UMXqH5e4LkK',
      };
      ipfsHash = fileHashes[fileName] || ipfsHash;

      // Step 1: Extract text from the image using the Gemini API
      const imagePath = `C:\\Users\\Akshara\\OneDrive\\Desktop\\sample prescriptions\\${fileName}`;
      const extractionResponse = await axios.post('http://127.0.0.1:5000/extract-prescription', { image_path: imagePath });
      const extractedData = extractionResponse.data;
      console.log('Extracted Data:', extractedData);

      // Step 2: Check for prescription error using the extracted data
      const errorResponse = await axios.post('http://127.0.0.1:5000/check-prescription-error', { prescription_json: extractedData });
      const isError = errorResponse.data.error_check_result;
      console.log('Final result: ', isError);
      if(isError==1){
        alert('There is a prescription error detected. Please re-verify the prescribed drugs')
      }
      else{
        setAlert(`No prescription error detected`, 'success');
      }

      // Step 3: Add the record to the smart contract
      await contract.methods.addRecord(ipfsHash, fileName, patientAddress).send({ from: accounts[0] });
      setAlert('New record uploaded', 'success');
      setAddRecord(false);

      // Step 4: Refresh records for the patient
      const records = await contract.methods.getRecords(patientAddress).call({ from: accounts[0] });
      setRecords(records);

    } catch (err) {
      setAlert('Record upload failed', 'error');
      console.error(err);
    }
  },
  [addPatientAddress, accounts, contract]
);



  if (loading) {
    return (
      <Backdrop sx={{ color: '#fff', zIndex: theme => theme.zIndex.drawer + 1 }} open={loading}>
        <CircularProgress color='inherit' />
      </Backdrop>
    )
  } else {
    return (
      <Box display='flex' justifyContent='center' width='100vw'>
        <Box width='60%' my={5}>
          {!accounts ? (
            <Box display='flex' justifyContent='center'>
              <Typography variant='h6'>Open your MetaMask wallet to get connected, then refresh this page</Typography>
            </Box>
          ) : (
            <>
              {role === 'unknown' && (
                <Box display='flex' justifyContent='center'>
                  <Typography variant='h5'>You're not registered, please go to home page</Typography>
                </Box>
              )}
              {role === 'patient' && (
                <Box display='flex' justifyContent='center'>
                  <Typography variant='h5'>Only doctor can access this page</Typography>
                </Box>
              )}
              {role === 'doctor' && (
                <>
                  <Modal open={addRecord} onClose={() => setAddRecord(false)}>
                    <AddRecordModal
                      handleClose={() => setAddRecord(false)}
                      handleUpload={addRecordCallback}
                      patientAddress={searchPatientAddress}
                    />
                  </Modal>

                  <Typography variant='h4'>Patient Records</Typography>
                  <Box display='flex' alignItems='center' my={1}>
                    <FormControl fullWidth>
                      <TextField
                        variant='outlined'
                        placeholder='Search patient by wallet address'
                        value={searchPatientAddress}
                        onChange={e => setSearchPatientAddress(e.target.value)}
                        InputProps={{ style: { fontSize: '15px' } }}
                        InputLabelProps={{ style: { fontSize: '15px' } }}
                        size='small'
                      />
                    </FormControl>
                    <Box mx={2}>
                      <CustomButton text={'Search'} handleClick={() => searchPatient()}>
                        <SearchRoundedIcon style={{ color: 'white' }} />
                      </CustomButton>
                    </Box>
                    <CustomButton text={'New Record'} handleClick={() => setAddRecord(true)} disabled={!patientExist}>
                      <CloudUploadRoundedIcon style={{ color: 'white' }} />
                    </CustomButton>
                  </Box>

                  {patientExist && records.length === 0 && (
                    <Box display='flex' alignItems='center' justifyContent='center' my={5}>
                      <Typography variant='h5'>No records found</Typography>
                    </Box>
                  )}

                  {patientExist && records.length > 0 && (
                    <Box display='flex' flexDirection='column' mt={3} mb={-2}>
                      {records.map((record, index) => (
                        <Box mb={2}>
                          <Record key={index} record={record} />
                        </Box>
                      ))}
                    </Box>
                  )}

                  <Box mt={6} mb={4}>
                    <Divider />
                  </Box>

                  <Typography variant='h4'>Register Patient</Typography>
                  <Box display='flex' alignItems='center' my={1}>
                    <FormControl fullWidth>
                      <TextField
                        variant='outlined'
                        placeholder='Register patient by wallet address'
                        value={addPatientAddress}
                        onChange={e => setAddPatientAddress(e.target.value)}
                        InputProps={{ style: { fontSize: '15px' } }}
                        InputLabelProps={{ style: { fontSize: '15px' } }}
                        size='small'
                      />
                    </FormControl>
                    <Box mx={2}>
                      <CustomButton text={'Register'} handleClick={() => registerPatient()}>
                        <PersonAddAlt1RoundedIcon style={{ color: 'white' }} />
                      </CustomButton>
                    </Box>
                  </Box>
                </>
              )}
            </>
          )}
        </Box>
      </Box>
    )
  }
}

export default Doctor
