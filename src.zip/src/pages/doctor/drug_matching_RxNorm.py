import requests

# RxNorm API endpoint for getting RxCUI by name
RXNORM_RXCUI_URL = "https://rxnav.nlm.nih.gov/REST/rxcui.json?name={drug_name}"
# RxNorm API endpoint to get related ingredients (generic) for a brand RxCUI
RXNORM_RELATION_URL = "https://rxnav.nlm.nih.gov/REST/rxcui/{rxcui}/related.json?tty=IN"  # IN stands for Ingredients
# OpenFDA API for drug indications
OPENFDA_DRUG_LABEL_URL = "https://api.fda.gov/drug/label.json?search=indications_and_usage:{disease}"

# Function to get RxCUI for a drug name (brand or generic)
def get_rxcui(drug_name):
    response = requests.get(RXNORM_RXCUI_URL.format(drug_name=drug_name))
    if response.status_code == 200:
        data = response.json()
        if "idGroup" in data and "rxnormId" in data["idGroup"]:
            return data["idGroup"]["rxnormId"][0]
    return None

# Function to get generic names from RxCUI
def get_generic_from_rxcui(rxcui):
    response = requests.get(RXNORM_RELATION_URL.format(rxcui=rxcui))
    generics = set()
    if response.status_code == 200:
        data = response.json()
        if "relatedGroup" in data:
            for conceptGroup in data["relatedGroup"]["conceptGroup"]:
                if "conceptProperties" in conceptGroup:
                    for concept in conceptGroup["conceptProperties"]:
                        generics.add(concept["name"].upper())
    return generics

# Main function to get brand-to-generic mapping
def get_brand_generic_mapping(drug_name):
    rxcui = get_rxcui(drug_name)
    if rxcui:
        generics = get_generic_from_rxcui(rxcui)
        if generics:
            return {drug_name.upper(): list(generics)[0]}
    return {drug_name.upper(): None}

# Function to validate prescription against OpenFDA
def is_drug_approved_for_disease(disease, generic_name):
    query_url = f"https://api.fda.gov/drug/label.json?search=indications_and_usage:{disease}"
    try:
        response = requests.get(query_url)
        if response.status_code == 200:
            data = response.json()
            if "results" in data:
                for result in data["results"]:
                    # Handle 'description' field if it exists and is a list
                    if 'description' in result:
                        descriptions = result['description']
                        if isinstance(descriptions, list):
                            for desc in descriptions:
                                if generic_name.lower() in desc.lower():
                                    return True
                        elif isinstance(descriptions, str):
                            if generic_name.lower() in descriptions.lower():
                                return True

                    # Handle 'indications_and_usage' if it exists and is a list
                    if 'indications_and_usage' in result:
                        indications = result['indications_and_usage']
                        if isinstance(indications, list):
                            for indication in indications:
                                if generic_name.lower() in indication.lower():
                                    return True
                        elif isinstance(indications, str):
                            if generic_name.lower() in indications.lower():
                                return True
    except Exception as e:
        print(f"Error querying OpenFDA: {e}")
    return False

# Main function that takes JSON input and returns 0 (correct) or 1 (incorrect)
def validate_prescriptions_json(input_data):
    disease = input_data.get("disease", [])
    prescribed_drugs = input_data.get("prescribed_drug", [])

    # Validate each prescribed drug
    for drug in prescribed_drugs:
        brand_generic_map = get_brand_generic_mapping(drug)
        generic_name = brand_generic_map.get(drug.upper())

        # If any drug is incorrect, return 1 immediately
        if generic_name:
            is_correct = False
            for d in disease:
                if is_drug_approved_for_disease(d, generic_name):
                    is_correct = True
                    break
            if not is_correct:
                return 1  # Return 1 if any prescription is incorrect
        else:
            return 1  # Return 1 if the generic name could not be found

    return 0  # Return 0 if all prescriptions are correct

# Example input JSON
input_data = {
    "disease": ["coronary artery disease"],
    "prescribed_drug": ["Acetaminophen", "Aspirin", "Clopidogrel"],
    "symptoms": []
}

# Validate prescriptions and print result
result = validate_prescriptions_json(input_data)
print(result)  # 0 if all correct, 1 if any prescription is incorrect
