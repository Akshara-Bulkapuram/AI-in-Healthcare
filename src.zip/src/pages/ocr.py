from doctr.io import DocumentFile
from doctr.models import ocr_predictor

def extract_text_from_image(image_path):
    """
    Extracts text from an image using Doctr's OCR model.

    Parameters:
    - image_path (str): The path to the image file.

    Returns:
    - str: Extracted text from the image.
    """
    # Load the OCR model
    model = ocr_predictor(det_arch='db_resnet50', reco_arch='crnn_vgg16_bn', pretrained=True)

    # Load the image
    doc = DocumentFile.from_images(image_path)

    # Perform OCR on the image
    result = model(doc)

    # Convert the result to a dictionary format
    result_dict = result.export()

    # Extract words from the result
    words = []
    for page in result_dict['pages']:
        for block in page['blocks']:
            for line in block['lines']:
                for word in line['words']:
                    words.append(word['value'])  # Extract the word text

    # Join the words into a single string
    all_text = " ".join(words)
    return all_text
