// import axios from 'axios';
// import { useCallback } from 'react';

import fs from 'fs';



// const projectId = process.env.REACT_APP_IPFS_PROJECT_ID;
// const projectSecret = process.env.REACT_APP_IPFS_PROJECT_SECRET;
// const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');





// import { urlSource, create } from 'kubo-rpc-client'

// const projectId = process.env.REACT_APP_IPFS_PROJECT_ID
// const projectSecret = process.env.REACT_APP_IPFS_PROJECT_SECRET
// const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64')

// const ipfs =  create({
//         host: 'ipfs.infura.io',
//         port: 5001,
//         protocol: 'https',
//         headers: {
//           authorization: auth
//         }
//       })

// export default ipfs




    
 
// //       for await (const file of client.addAll(globSource("./docs", "**/*"))) {
// //         console.log(file)
// //       }
// // }

// // addFile()