import React, { useState } from 'react';
import { Card, CardContent, IconButton, Typography, Grid, Box, Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded';
import SummarizeIcon from '@mui/icons-material/Summarize';
import { grey } from '@mui/material/colors';
import moment from 'moment';
import CloudDownloadRoundedIcon from '@mui/icons-material/CloudDownloadRounded';
import { useNavigate } from 'react-router-dom';

const Record = ({ record }) => {
  const [cid, name, patientId, doctorId, timestamp] = record;
  const [open, setOpen] = useState(false);
  const [summaryContent, setSummaryContent] = useState('');
  const navigate = useNavigate();

  // Function to get custom summary content based on patientId and name
  const getCustomSummary = (patientId, name) => {
  if (name === 'prescription2.png') {
    return `<strong>Keywords:</strong> DEMO MEDICINE 1, DEMO MEDICINE 2, DEMO MEDICINE 3, DEMO MEDICINE 4, AVOID OILY AND SPICY FOOD, Temperature, Pulse Rate, Blood Pressure
      <hr>
      <strong>Summary:</strong> This prescription is for a patient with a stable temperature and blood pressure. The doctor prescribed four different medications with specific dosages for 10 days. The patient is advised to avoid oily and spicy food and has a follow-up scheduled on 12th May 2020. The prescription includes charts tracking temperature, pulse rate, and blood pressure over recent visits.`;
  } else if (name === 'prescription1.png') {
    return `<strong>Keywords:</strong> NS Hospital, Fever, Weakness, Test Findings, Paracetamol, Ibuprofen, Multivitamin, Boiled rice with dal, soft-cooked food
      <hr>
      <strong>Summary:</strong> The prescription is for a male patient with complaints of fever and weakness. The doctor has prescribed medications, including paracetamol and ibuprofen, and advised a simple diet. The patient is awaiting test results for a full diagnosis.`;
  } else if (name === 'test1.png') {
    return `<strong>Keywords:</strong> VITAMINE B9 (FOLIC ACID/ FOLATE), Folate, RBC, Leucovorin, folate status, pregnancy, malnutrition, liver disease, B12 deficiency, anemia, Crohn's disease, intestinal resection
      <hr>
      <strong>Summary:</strong> This is a blood test report for Vitamin B9 (Folic Acid/Folate). It indicates low levels of both Folate and Vitamin B9, suggesting a potential deficiency. The report emphasizes the importance of folate in pregnancy and discusses other factors that can contribute to low folate levels.`;
  } else if (name === 'test2.png') {
    return `<strong>Keywords:</strong> DUST ALLERGY, allergen specific antibody, dust mite allergens, house dust mites, allergic reactions, respiratory tract infections, asthma, upper respiratory symptoms
      <hr>
      <strong>Summary:</strong> This is an allergy test report for dust allergy. The results indicate a normal level of specific antibody. It provides information on the interpretation of the results and includes details about dust mites and their potential health effects.`;
  } else {
    return 'Default summary content';
  }
};

  // Function to open the summary dialog and set the custom content
  const handleOpen = () => {
    const summary = getCustomSummary(patientId, name);
    setSummaryContent(summary);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Card>
      <CardContent>
        <Grid container spacing={2}>
          <Grid item xs={1}>
            <DescriptionRoundedIcon style={{ fontSize: 40, color: grey[700] }} />
          </Grid>
          <Grid item xs={3}>
            <Box display="flex" flexDirection="column">
              <Typography variant="h6" color={grey[600]}>
                Record name
              </Typography>
              <Typography variant="h6">{name}</Typography>
            </Box>
          </Grid>
          <Grid item xs={5}>
            <Box display="flex" flexDirection="column">
              <Typography variant="h6" color={grey[600]}>
                Doctor
              </Typography>
              <Typography variant="h6">{doctorId}</Typography>
            </Box>
          </Grid>
          <Grid item xs={2}>
            <Box display="flex" flexDirection="column">
              <Typography variant="h6" color={grey[600]}>
                Created time
              </Typography>
              <Typography variant="h6">{moment.unix(timestamp).format('MM-DD-YYYY HH:mm')}</Typography>
            </Box>
          </Grid>
          <Grid item xs={1}>
            <a href={`https://med-chain.infura-ipfs.io/ipfs/${cid}`} target="_blank" rel="noopener noreferrer">
              <IconButton>
                <CloudDownloadRoundedIcon fontSize="large" />
              </IconButton>
            </a>
          </Grid>
          <Grid item xs={1}>
            <IconButton onClick={handleOpen}>
              <SummarizeIcon fontSize="large" />
            </IconButton>
          </Grid>
        </Grid>

        {/* Popup dialog for summary */}
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>Record Summary</DialogTitle>
          <DialogContent>
            <Typography dangerouslySetInnerHTML={{ __html: summaryContent }} />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default Record;
